<?php 
setcookie("pismo", "Na skroty", time()+3600, "/", "localhost", false); 
if(isset($_COOKIE["pismo"])){
    echo "Jestes naszym klientem.";
} else {
    echo "Witamy na naszej stronie";
} 
?>
