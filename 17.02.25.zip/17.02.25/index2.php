<?php
$mies = 2592000 + time();
setcookie("Wizyta", data("F js - g:ia"), $mies );
?>
<?php
if(isset($_COOKIE['wizyta'])){
    $ostatnia = $_COOKIE[]
    echo "Witamy panowie! ostatnia wizyta byla: "
    $ostatnia
} else {
    echo "Witaj na nszaej stronie";
}