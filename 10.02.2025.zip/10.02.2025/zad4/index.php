<?php

session_start();


$conn = new mysqli("localhost", "root", "", "logowanie_db");

if ($conn->connect_error) die("Błąd połączenia: " . $conn->connect_error);


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];

    $password = $_POST["password"];



    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $stmt->store_result();

    

    if ($stmt->num_rows > 0) {

        $stmt->bind_result($hashed_password);

        $stmt->fetch();

        

        if (password_verify($password, $hashed_password)) {

            $_SESSION["user"] = $username;

            header("Location: index.php");

            exit();

        } else {

            echo "<p style='color:red;'>Nieprawidłowe hasło!</p>";

        }

    } else {

        echo "<p style='color:red;'>Nieprawidłowy login!</p>";

    }

    $stmt->close();

}



if (isset($_GET["logout"])) {

    session_destroy();

    header("Location: index.php");

    exit();

}





if (isset($_SESSION["user"])) {

    echo "<h2>Witaj, " . htmlspecialchars($_SESSION["user"]) . "!</h2>";

    echo "<a href='?logout=true'>Wyloguj</a>";

} else {



    echo '

    <h2>Logowanie</h2>

    <form method="post">

        <label>Login:</label>

        <input type="text" name="username" required><br>

        <label>Hasło:</label>

        <input type="password" name="password" required><br>

        <input type="submit" value="Zaloguj">

    </form>';

}



$conn->close();

?>