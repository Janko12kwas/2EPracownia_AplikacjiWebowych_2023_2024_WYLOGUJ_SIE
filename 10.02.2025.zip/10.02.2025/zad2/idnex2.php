<!DOCTYPE html>

<html lang="pl">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Odebrane dane</title>

</head>

<body>

    <h2>Otrzymane dane:</h2>

    <?php

    if(isset($_GET['imie']) && isset($_GET['nazwisko']) && isset($_GET['email'])) {

        $imie = htmlspecialchars($_GET['imie']);

        $nazwisko = htmlspecialchars($_GET['nazwisko']);

        $email = htmlspecialchars($_GET['email']);



        echo "<p><strong>Imię:</strong> $imie</p>";

        echo "<p><strong>Nazwisko:</strong> $nazwisko</p>";

        echo "<p><strong>Email:</strong> $email</p>";

    } else {

        echo "<p>Nie przesłano danych.</p>";

    }

    ?>

</body>

</html>

