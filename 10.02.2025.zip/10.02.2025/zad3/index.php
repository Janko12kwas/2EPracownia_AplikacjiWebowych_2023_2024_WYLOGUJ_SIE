<!DOCTYPE html>

<html lang="pl">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Rejestracja</title>

</head>

<body>

    <h2>Rejestracja użytkownika</h2>

    <form action="register.php" method="post">

        <label for="login">Login:</label>

        <input type="text" id="login" name="login" required><br><br>



        <label for="password">Hasło:</label>

        <input type="password" id="password" name="password" required><br><br>



        <input type="submit" value="Zarejestruj się">

    </form>



    <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $conn = new mysqli("localhost", "root", "", "rejestracja");



        if ($conn->connect_error) {

            die("Błąd połączenia: " . $conn->connect_error);

        }



        $login = $_POST['login'];

        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);



        

        $stmt = $conn->prepare("SELECT id FROM users WHERE login = ?");

        $stmt->bind_param("s", $login);

        $stmt->execute();

        $stmt->store_result();



        if ($stmt->num_rows > 0) {

            echo "<p style='color: red;'>Login już istnieje! Wybierz inny.</p>";

        } else {

           

            $stmt = $conn->prepare("INSERT INTO users (login, password) VALUES (?, ?)");

            $stmt->bind_param("ss", $login, $password);

            if ($stmt->execute()) {

                echo "<p style='color: green;'>Rejestracja zakończona sukcesem!</p>";

            } else {

                echo "<p style='color: red;'>Błąd rejestracji.</p>";

            }

        }



        $stmt->close();

        $conn->close();

    }

    ?>

</body>

</html>

