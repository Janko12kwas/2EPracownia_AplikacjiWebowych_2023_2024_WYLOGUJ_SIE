function sendMessage() {
  const inputFied = document.getElementById("input-text");
  const messageText = inputField.value;
  if (messageText.trim() === "") return;
}
