<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = $_POST['address'];
    $user_id = $_SESSION['user_id']; 

    if (isset($_POST['cart']) && !empty($_POST['cart'])) {
        $cart = json_decode($_POST['cart'], true);
    } else {
        die('Koszyk jest pusty!');
    }

    $totalPrice = 0;
    foreach ($cart as $item) {
        $totalPrice += $item['price'] * $item['quantity'];
    }

    $conn = new mysqli('localhost', 'root', '', 'sklep_z_ubranami');
    if ($conn->connect_error) {
        die("Połączenie z bazą danych nieudane: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO orders (user_id, address, total_price) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die('Błąd przygotowania zapytania: ' . $conn->error);
    }
    $stmt->bind_param("isd", $user_id, $address, $totalPrice);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $orderId = $stmt->insert_id; 

        foreach ($cart as $item) {
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_name, product_price, quantity) VALUES (?, ?, ?, ?)");
            if ($stmt === false) {
                die('Błąd przygotowania zapytania do produktów: ' . $conn->error);
            }
            $stmt->bind_param("isdi", $orderId, $item['name'], $item['price'], $item['quantity']);
            $stmt->execute();
        }

        header("Location: order_confirmation.php?order_id=$orderId");
        exit();
    } else {
        die('Błąd zapisu zamówienia');
    }
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz zamówienia</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Formularz zamówienia</h1>
    </header>

    <section class="order-form">
        <h2>Podaj dane wysyłki:</h2>
        <form method="POST" action="order_form.php">
            <label for="address">Adres wysyłki:</label>
            <input type="text" id="address" name="address" required>
            <input type="hidden" name="cart" value='<?php echo json_encode($_SESSION['cart']); ?>'>

            <button type="submit">Złóż zamówienie</button>
        </form>
    </section>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
            <a href="contact.php" class="contact-link">Kontakt</a>
        </div>
    </footer>
</body>
</html>
