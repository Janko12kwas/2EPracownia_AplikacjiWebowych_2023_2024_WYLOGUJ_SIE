<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    $user_logged_in = false;
} else {
    $user_logged_in = true;
}

if (isset($_POST['accept_cookies'])) {
    setcookie("cookies_accepted", "true", time() + (86400 * 30), "/");
    header("Location: index.php"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep z ubraniami</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Sklep z ubraniami</h1>
        <nav>
            <ul>
                <li><a href="index.php">Strona główna</a></li>
                <li><a href="cart.php">Koszyk</a></li>
                <?php if (!$user_logged_in): ?>
                    <li><a href="login.php">Zaloguj się</a></li>
                    <li><a href="register.php">Zarejestruj się</a></li>
                <?php else: ?>
                    <li><a href="logout.php">Wyloguj się</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>

    <section class="products">
        <div class="product">
            <img src="koszulka.jpg" alt="Koszulka" class="product-image">
            <h2>Koszulka</h2>
            <p>Cena: 89.99 zł</p>
            <label for="koszulka-quantity">Ilość:</label>
            <input type="number" id="koszulka-quantity" value="1" min="1">
            <button class="add-to-cart" data-product="koszulka" data-price="89.99" data-name="Koszulka" data-image="koszulka.jpg">Dodaj do koszyka</button>
        </div>
        <div class="product">
            <img src="bluza.jpg" alt="Bluza" class="product-image">
            <h2>Bluza</h2>
            <p>Cena: 139.99 zł</p>
            <label for="bluza-quantity">Ilość:</label>
            <input type="number" id="bluza-quantity" value="1" min="1">
            <button class="add-to-cart" data-product="bluza" data-price="139.99" data-name="Bluza" data-image="bluza.jpg">Dodaj do koszyka</button>
        </div>
    </section>

    <script>
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                if (!<?php echo $user_logged_in ? 'true' : 'false'; ?>) {
                    alert('Musisz być zalogowany, aby dodać produkty do koszyka!');
                    return;
                }

                const productName = this.getAttribute('data-name');
                const productPrice = parseFloat(this.getAttribute('data-price'));
                const productId = this.getAttribute('data-product');
                const productImage = this.getAttribute('data-image');
                const quantityInput = document.getElementById(`${productId}-quantity`);
                const quantity = parseInt(quantityInput.value);

                let cart = JSON.parse(localStorage.getItem('cart')) || [];

                const existingProductIndex = cart.findIndex(item => item.id === productId);
                if (existingProductIndex !== -1) {
                    cart[existingProductIndex].quantity += quantity;
                } else {
                    cart.push({ name: productName, price: productPrice, id: productId, quantity: quantity, image: productImage });
                }
                localStorage.setItem('cart', JSON.stringify(cart));

                alert(`${productName} - ${quantity} sztuk zostało dodane do koszyka!`);
            });
        });
    </script>

<footer>
    <div class="footer-container">
        <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
        <a href="contact.php" class="contact-link">Kontakt</a>
    </div>
</footer>


    <?php if (!isset($_COOKIE['cookies_accepted'])): ?>
    <div id="cookie-banner" class="cookie-banner">
        <p>Ta strona używa plików cookies, aby zapewnić najlepszą jakość usług. Kontynuując, zgadzasz się na ich użycie.</p>
        <form method="POST">
            <button type="submit" name="accept_cookies">Akceptuję</button>
        </form>
    </div>
    <?php endif; ?>

</body>
</html>
