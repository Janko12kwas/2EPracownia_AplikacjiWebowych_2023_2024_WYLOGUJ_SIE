<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];

    $conn = new mysqli('localhost', 'root', '', 'sklep_z_ubranami');

    if ($conn->connect_error) {
        die("Połączenie z bazą nieudane: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Użytkownik o tej nazwie już istnieje!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
        $stmt->bind_param('sss', $username, $password, $email);
        $stmt->execute();
        header("Location: login.php"); 
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
    <link rel="stylesheet" href="style2.css"> 
</head>
<body>

<main>
    <div class="form-container">
        <h2>Utwórz nowe konto</h2>
        <form method="POST" action="register.php">
            <div>
                <label for="username">Nazwa użytkownika:</label>
                <input type="text" id="username" name="username" required><br>
            </div>

            <div>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br>
            </div>

            <div>
                <label for="password">Hasło:</label>
                <input type="password" id="password" name="password" required><br>
            </div>

            <button type="submit">Zarejestruj się</button>

            <?php if (isset($error)) echo "<p class='error-message'>$error</p>"; ?>
        </form>
    </div>
</main>

<footer>
    <div class="footer-container">
        <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
        <a href="contact.php" class="contact-link">Kontakt</a>
    </div>
</footer>

</body>
</html>
