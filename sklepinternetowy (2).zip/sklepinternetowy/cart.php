<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koszyk</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Twój Koszyk</h1>
        <nav>
            <ul>
                <li><a href="index.php">Strona główna</a></li>
                <li><a href="cart.php">Koszyk</a></li>
            </ul>
        </nav>
    </header>

    <section class="cart">
        <h2>Produkty w koszyku:</h2>
        <ul id="cart-items">
          
        </ul>
        <p><strong>Łączna cena: <span id="total-price">0 zł</span></strong></p>
        <button id="checkout">Złóż zamówienie</button>
    </section>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
            <a href="contact.php" class="contact-link">Kontakt</a>
        </div>
    </footer>

    <script>
        function displayCart() {
            const cartItems = document.getElementById('cart-items');
            cartItems.innerHTML = '';
            let totalPrice = 0;

            const cart = JSON.parse(localStorage.getItem('cart')) || [];

            cart.forEach((item, index) => {
                const li = document.createElement('li');
                li.innerHTML = `<img src="${item.image}" alt="${item.name}" class="cart-product-image"> ${item.name} - ${item.price} zł x ${item.quantity} 
                <button class="remove-item" data-index="${index}">Usuń</button>`;
                cartItems.appendChild(li);
                totalPrice += item.price * item.quantity;
            });
            document.getElementById('total-price').textContent = `${totalPrice} zł`;
            document.querySelectorAll('.remove-item').forEach(button => {
                button.addEventListener('click', function() {
                    const index = parseInt(this.getAttribute('data-index'));
                    removeItemFromCart(index);
                });
            });
        }

        function removeItemFromCart(index) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart.splice(index, 1);
            localStorage.setItem('cart', JSON.stringify(cart));
            displayCart();
        }

        document.getElementById('checkout').addEventListener('click', function() {
            window.location.href = 'order_form.php';
        });

        displayCart();
    </script>
</body>
</html>
