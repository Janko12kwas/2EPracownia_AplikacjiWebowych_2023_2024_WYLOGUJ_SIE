<?php
$orderId = $_GET['order_id'];
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Potwierdzenie zamówienia</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <header>
        <h1>Potwierdzenie zamówienia</h1>
    </header>

    <section class="confirmation">
        <h2>Dziękujemy za zamówienie!</h2>
        <p>Twoje zamówienie zostało przyjęte. Numer zamówienia to: <strong>#<?php echo $orderId; ?></strong></p>
    </section>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
            <a href="contact.php" class="contact-link">Kontakt</a>
        </div>
    </footer>
</body>
</html>
