<?php
$host = 'localhost';
$dbname = 'sklep_z_ubranami';
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Błąd połączenia z bazą danych: ' . $e->getMessage();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $message = $_POST['message'];

    if (filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO kontakt (email, message) VALUES (:email, :message)");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':message', $message);
        if ($stmt->execute()) {
            $successMessage = "Wiadomość została wysłana!";
        } else {
            $errorMessage = "Wystąpił problem podczas wysyłania wiadomości.";
        }
    } else {
        $errorMessage = "Proszę wprowadzić poprawny email oraz wiadomość.";
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz kontaktowy</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Kontakt</h1>
    </header>

    <section class="contact-form-section">
        <div class="form-container">
            <h2>Skontaktuj się z nami</h2>

            <?php if (isset($successMessage)): ?>
                <p class="success-message"><?= $successMessage ?></p>
            <?php elseif (isset($errorMessage)): ?>
                <p class="error-message"><?= $errorMessage ?></p>
            <?php endif; ?>

            <form action="contact.php" method="POST">
                <div class="form-group">
                    <label for="email">Twój email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Wiadomość:</label>
                    <textarea id="message" name="message" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit">Wyślij wiadomość</button>
                </div>
            </form>
        </div>
    </section>

    <footer>
        <div class="footer-container">
            <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
            <a href="contact.php" class="contact-link">Kontakt</a>
        </div>
    </footer>
</body>
</html>
