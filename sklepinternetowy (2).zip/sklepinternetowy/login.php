<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $conn = new mysqli('localhost', 'root', '', 'sklep_z_ubranami');

    if ($conn->connect_error) {
        die("Połączenie z bazą nieudane: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit();
        } else {
            $error = "Nieprawidłowe hasło!";
        }
    } else {
        $error = "Nie znaleziono użytkownika!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div class="login-container">
        <h2>Logowanie</h2>
        <form method="POST" action="login.php">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" id="username" name="username" required><br>

            <label for="password">Hasło:</label>
            <input type="password" id="password" name="password" required><br>

            <button type="submit">Zaloguj się</button>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        </form>
        <p>Nie masz konta? <a href="register.php">Zarejestruj się</a></p>
    </div>

    <footer>
    <div class="footer-container">
        <p>&copy; 2025 Twoja Strona. Wszelkie prawa zastrzeżone.</p>
        <a href="contact.php" class="contact-link">Kontakt</a>
    </div>
</footer>
</body>
</html>
