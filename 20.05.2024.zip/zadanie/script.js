document.getElementById('przycisk').addEventListener('click', function()
{
    const ksztalt = document.getElementById('dane').value;
    const demo = document.getElementById('demo').innerText;
    if(ksztalt = "1") {
         demo = "cytryna;"
    }
})

