
var users = new Array("user1", "user2", "user3");
var passwords = new Array("kod1", "kod2", "kod3");
function getCookie(name)
{
  var c = document.cookie;
  point = c.indexOf(name);
  if (point != -1){
    endAt = c.indexOf (";", point + name.length);
    if (endAt == -1) endAt = c.length;
    var temp = c.substring(point + 1 + name.length, endAt);
    return temp;
  }
  return false;
}
function setCookie(name, value)
{
  data = new Date();
  data.setMonth(data.getMonth() + 1);
  var cookie = name + "=" + value + ";";
  cookie += "expires=" + data.toGMTString();
  document.cookie = cookie;
}
function sprawdz_haslo(user, pass)
{  
  for(var i = 0; i < users.length; i++){
    if((user == users[i]) && (pass == passwords[i]))
      return true;
  }
  return false;
}
function check()
{
  var user = document.form1.user.value;
  var pass = document.form1.pass.value;
  if(!sprawdz_haslo(user, pass)){
      alert('Niepoprawne hasło!');
  }
  else{
    if(document.form1.autoLogin.checked){
      setCookie("autoLogin", "true");
    }
    document.location.href = "wejdz.html";
  }
}
function checkAutoLogin()
{
  if(getCookie("autoLogin") == "true"){
    document.location.href = "wejdz.html";
  }
}