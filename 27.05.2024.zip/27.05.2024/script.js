function change1() {
    var color = document.getElementById("prawy");
    color.style.backgroundColor = "Indigo";
}

function change2() {
    var color = document.getElementById("prawy");
    color.style.backgroundColor = "Steelblue";
}

function change3() {
    var color = document.getElementById("prawy");
    color.style.backgroundColor = "olive";
}